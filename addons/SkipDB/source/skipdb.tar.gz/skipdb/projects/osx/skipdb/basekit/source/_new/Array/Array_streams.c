
void Array_print(Array *self);
void Array_asString(Array *self);

void Array_writeToBStream_(Array *self, BStream *bstream);
void Array_readFromBStream_(Array *self, BStream *bstream);



