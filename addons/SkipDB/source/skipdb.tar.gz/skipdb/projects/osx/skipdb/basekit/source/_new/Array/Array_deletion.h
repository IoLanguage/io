/*   
 *   copyright: Steve Dekorte, 2005. All rights reserved.
 *   license: See _BSDLicense.txt.
 */
 

void Array_removeLast(Array *self);
void Array_removeAt_(Array *self, size_t index);
void Array_removeFrom_to_(Array *self, size_t from, size_t to);

