/*
 *  Array_math.c
 *  Io
 *
 *  Created by steve on 2005/6/1.
 *  Copyright 2005 __MyCompanyName__. All rights reserved.
 *
 */

#include "Array_math.h"

