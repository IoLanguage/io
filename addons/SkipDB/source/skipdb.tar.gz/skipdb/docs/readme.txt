
About
=====
SkipDB is a small, transactional and fast ordered key/value pair database implemented with a skip lists instead of b-tree.

This is a *development* release. 

Credits
=======
Thanks to Bill Pugh for developing skip lists and to Greg Burd for recommending their use in a database.

Feedback welcome,
- Steve Dekorte, steve at dekorte dot com