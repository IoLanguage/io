/*   
copyright: Steve Dekorte, 2004. All rights reserved.
license: See _BSDLicense.txt.

object: main
module: SkipDB
description: test harness
*/

#include <stdio.h>
#include "SkipDBM.h"
#include "PortableGettimeofday.h"
#include <sys/stat.h>     
#include <sys/types.h>     
#include <fcntl.h>

#ifndef _WIN32
#include <unistd.h>
#endif

#define MAX 10000

void printNum(float n)
{
	if (n > 1000000000)
	{
		printf("%.1fB", n / 1000000000.0);
	}
	else
		if (n > 10000000)
		{
			printf("%.0fM", n / 1000000.0);
		}
	else
		if (n > 1000000)
		{
			printf("%.1fM", n / 1000000.0);
		}
	else if (n > 10000)
	{
		printf("%.0fK", n / 1000.0);
	}
	
	else if (n > 1000)
	{
		printf("%.1fK", n / 1000.0);
	}
	else
	{
		printf("%.1f", n);
	}
}

double mtime(void)
{
	double v;
	struct timeval tp;
	struct timezone tz;
	gettimeofday(&tp, &tz);
	v = tp.tv_sec;
	v += ((double)tp.tv_usec)/1000000.0;
	return v;
}

double timerDone(double t1, char *label)
{
	float d = mtime() - t1;
	//printf("%i %s in %f secs\n", MAX, label, d);
	
	if (label) 
	{
		printNum(((float)MAX) / d);
		printf(" %s per second\n", label);
	}
	return d;
}

PID_TYPE testWrite(UDB *udb, char *s)
{
	Datum d = Datum_FromCString_(s);
	PID_TYPE pid;
	pid = UDB_put_(udb, d);
	printf("write %i : '%s' \n", (int)pid, s);
	return pid;
}

void testRead(UDB *udb, PID_TYPE pid, char *expect)
{
	Datum d = UDB_at_(udb, pid);
	
	if (d.size)
	{	
		if (!expect)
		{
			printf("read %i : '%s' but expected NULL\n", (int)pid, (char *)d.data);
			exit(-1);
		}
		
		if (strcmp((char *)d.data, expect) != 0)
		{
			printf("read %i : '%s' but expected '%s'\n", (int)pid, (char *)d.data, expect);
			exit(-1);
		}
		
		printf("read %i : '%s'\n", (int)pid, (char *)d.data);
	}
	else
	{
		
		if (expect)
		{
			printf("read %i : NULL but expected '%s'\n", (int)pid, expect);
			exit(-1);
		}	
		
		printf("read %i : MISSING\n", (int)pid);
	}
}

void testRemove(UDB *udb, PID_TYPE pid)
{
	printf("remove %i\n", (int)pid);
	UDB_removeAt_(udb, pid);
}

void udbTest(void)
{
	UDB *udb = UDB_new();
	PID_TYPE pid1, pid2, pid3;
	
	UDB_delete(udb);
	UDB_open(udb);
	
	printf("\n-------------------------\n");
	printf("unordered db test:\n\n");
	
	UDB_beginTransaction(udb);
	pid1 = testWrite(udb, "111");
	pid2 = testWrite(udb, "222");
	pid3 = testWrite(udb, "333");
	UDB_commitTransaction(udb);
	
	/* read */
	printf("\n");
	
	testRead(udb, pid1, "111");
	testRead(udb, pid2, "222");
	testRead(udb, pid3, "333");
	
	//UDB_show(udb);
	
	/* remove */
	printf("\n");
	
	UDB_beginTransaction(udb);
	testRemove(udb, pid2);
	printf("\n");
	UDB_commitTransaction(udb);
	
	testRead(udb, pid1, "111");
	testRead(udb, pid2, (char *)NULL);
	testRead(udb, pid3, "333");
	
	/* compact */
	
	printf("\ncompact\n\n");
	
	UDB_compact(udb);
	
	/* read */
	
	testRead(udb, pid1, "111");
	testRead(udb, pid2, 0x0);
	testRead(udb, pid3, "333");
	
	printf("\n");
	UDB_beginTransaction(udb);
	pid2 = testWrite(udb, "zzz");
	UDB_commitTransaction(udb);
	
	printf("\nread\n\n");
	
	testRead(udb, pid1, "111");
	testRead(udb, pid2, "zzz");
	testRead(udb, pid3, "333");
	
	UDB_free(udb);
	printf("\n");
}

void udbSpeedTest(void)
{
	UDB *udb = UDB_new();
	Datum d;
	int i;
	char data[128];
	double t1;
	
	//UDB_setPath_(udb, "/Volumes/RAID1/testdb");
	//UDB_setLogPath_(udb, "/Volumes/RAID1");
	UDB_delete(udb);
	UDB_open(udb);
	
	printf("\n-------------------------\n");
	printf("udb speed test:\n\n");
	
	//UDB_showIndex(udb);
	
	t1 = mtime();
	
	for (i = 1; i < MAX; i ++)
	{
		PID_TYPE pid;
		sprintf(data, "%i", i);
		d = Datum_FromCString_(data);
		UDB_beginTransaction(udb);
		pid = UDB_put_(udb, d);
		UDB_commitTransaction(udb);
		
		{
			Datum d2 = UDB_at_(udb, pid);
			
			if (!d2.size || strcmp((char *)d2.data, (char *)d.data) != 0)
			{
				printf("error with write\n");
				exit(-1);
			}
		}
	}
	
	timerDone(t1, "individual transactional inserts");
	
	//UDB_showIndex(udb);
	
	UDB_close(udb);
	UDB_delete(udb);
	UDB_open(udb);
	
	t1 = mtime();
	UDB_beginTransaction(udb);
	
	for (i = 1; i < MAX; i ++)
	{
		PID_TYPE pid;
		sprintf(data, "%i", i);
		d = Datum_FromCString_(data);
		pid = UDB_put_(udb, d);
		//printf("wrote to pid %i\n", (int)pid);
		
	}
	
	UDB_commitTransaction(udb);
	timerDone(t1, "group transactional inserts");
	
	//UDB_showIndex(udb);
	
	t1 = mtime();
	for (i = 1; i < MAX; i ++)
	{
		PID_TYPE pid = i;
		sprintf(data, "%i", i);
		d = UDB_at_(udb, pid);
		
		if (!d.size)
		{
			printf("expected '%s' but got NULL for pid %i\n", data, (int)pid);
			exit(1);
		}
		
		if (strcmp((char *)data, (char *)d.data) != 0)
		{
			printf("data '%s' doesn't match for pid %i\n", d.data, (int)pid);
			exit(1);
		}
		
		//printf("%i = %s\n", (int)pid, (char *)data);
	}
	timerDone(t1, "uncached reads");
	
	t1 = mtime();
	UDB_beginTransaction(udb);
	for (i = 1; i < MAX; i = i + 2)
	{
		/*
		 if (UDB_at_(udb, 9999).size == 0)
		 {
			 printf("9999 gone\n");
		 }
		 */
		UDB_removeAt_(udb, i);
	}
	UDB_commitTransaction(udb);
	timerDone(t1, "transactional removes");
	
	t1 = mtime();
	{
		double c = UDB_compact(udb);
		double dt = timerDone(t1, 0x0);
		//printf("compacted %i records in %.3f seconds\n", (int)c, (float)dt);
		printf("%.1fK transactional compactions per second\n", (c / dt)/1000.0);
	}
	//timerDone(t1, "transactional compactions");
	
	UDB_free(udb);
	printf("\n");
}

void skipWrite(SkipDB *sdb, char *k, char *v)
{
	printf("skip write %s = %s\n", k, v);
	SkipDB_at_put_(sdb, Datum_FromCString_(k), Datum_FromCString_(v));
	//SkipDB_show(sdb);
}

char *skipRead(SkipDB *sdb, char *k, char *expected)
{
	Datum kd = Datum_FromCString_(k);
	Datum d = SkipDB_at_(sdb, kd);
	
	if (d.size)
	{
		printf("skip %s = %s\n", k, (char *)d.data);
		
		if (!expected)
		{
			printf("read expected NULL but got '%s'\n", d.data);
			SkipDB_at_(sdb, kd);
			exit(-1);
		}
		else if (memcmp(d.data, expected, d.size) != 0)
		{
			printf("read expected '%s' but got '%s'\n", expected, d.data);
			SkipDB_at_(sdb, kd);
			exit(-1);
		}
	}
	else
	{
		printf("skip %s = MISSING\n", k);
		
		if (expected)
		{
			printf("read expected '%s' but got NULL\n", expected);
			SkipDB_at_(sdb, kd);
			exit(-1);
		}
	}
	
	return (char *)d.data;
}

void skipRemove(SkipDB *sdb, char *k)
{
	printf("skip remove %s\n", k);
	SkipDB_removeAt_(sdb, Datum_FromCString_(k));
}

void skipTest(void)
{
	SkipDBM *sdbm = SkipDBM_new();
	//Datum name = Datum_FromCString_("test");
	SkipDB *sdb;
	
	SkipDBM_delete(sdbm);
	SkipDBM_free(sdbm);
	
	sdbm = SkipDBM_new();
	SkipDBM_open(sdbm);
	
	sdb = SkipDBM_rootSkipDB(sdbm);
	
	printf("\n-------------------------\n");
	printf("skipdb test:\n\n");
	
	SkipDBM_beginTransaction(sdbm);
	skipWrite(sdb, "b", "B");
	SkipDBM_commitTransaction(sdbm);
	
	SkipDB_clearCache(sdb);
	SkipDBM_free(sdbm);
	sdbm = SkipDBM_new();
	SkipDBM_open(sdbm);
	
	skipRead(sdb, "b", "B");
	
	SkipDBM_beginTransaction(sdbm);
	skipWrite(sdb, "a", "A");
	SkipDBM_commitTransaction(sdbm);
	
	SkipDBM_beginTransaction(sdbm);
	skipWrite(sdb, "c", "C");
	SkipDBM_commitTransaction(sdbm);
	
	SkipDB_clearCache(sdb);
	
	/* read */
	printf("\n");
	
	skipRead(sdb, "a", "A");
	skipRead(sdb, "b", "B");
	skipRead(sdb, "c", "C");
	
	SkipDB_show(sdb);
	
	SkipDBM_free(sdbm);
	sdbm = SkipDBM_new();
	SkipDBM_open(sdbm);
	
	/* remove */
	printf("\n");
	
	SkipDBM_beginTransaction(sdbm);
	skipRemove(sdb, "b");
	SkipDBM_commitTransaction(sdbm);
	
	SkipDB_clearCache(sdb);
	
	/* read */
	printf("\n");
	
	skipRead(sdb, "a", "A");
	skipRead(sdb, "b", NULL);
	skipRead(sdb, "c", "C");
	
	/* compact */
	
	printf("\ncompact\n\n");
	
	SkipDBM_compact(sdbm);
	
	/* read */
	
	skipRead(sdb, "a", "A");
	skipRead(sdb, "b", NULL);
	skipRead(sdb, "c", "C");
	
	SkipDB_show(sdb);
	
	SkipDBM_beginTransaction(sdbm);
	skipWrite(sdb, "d", "D");
	SkipDBM_commitTransaction(sdbm);
	
	SkipDB_show(sdb);
	
	printf("\ncursor\n\n");
	{
		SkipDBRecord *r;
		SkipDBCursor *cursor = SkipDB_createCursor(sdb);
		r = SkipDBCursor_first(cursor);
		while (r)
		{
			printf("'%s':'%s'\n", 
				  ByteArray_asCString(SkipDBRecord_key(r)), 
				  ByteArray_asCString(SkipDBRecord_value(r)));
			r = SkipDBCursor_next(cursor);
		}
	}
	
	SkipDBM_free(sdbm);
	printf("\n");
}

void skipSpeedTest(void)
{
	SkipDBM *sdbm = SkipDBM_new();
	SkipDB *sdb;
	
	int i;
	char key[128];
	double t1;
	
	SkipDBM_delete(sdbm);
	SkipDBM_open(sdbm);
	sdb = SkipDBM_rootSkipDB(sdbm);
	
	printf("\n-------------------------\n");
	printf("skipdb speed test:\n\n");
	
	t1 = mtime();
	for (i = MAX; i < MAX * 2; i ++)
	{
		sprintf(key, "000%i", i); // key size == 8
		SkipDBM_beginTransaction(sdbm);
		SkipDB_at_put_(sdb, Datum_FromCString_(key), Datum_FromCString_(key));
		SkipDBM_commitTransaction(sdbm);
	}
	timerDone(t1, "individual transactional inserts");
	
	//SkipDB_show(sdb);
	
	SkipDBM_close(sdbm);
	SkipDBM_delete(sdbm);
	SkipDBM_open(sdbm);   
	sdb = SkipDBM_rootSkipDB(sdbm);
	
	t1 = mtime();
	SkipDBM_beginTransaction(sdbm);
	for (i = MAX; i < MAX * 2; i ++)
	{
		sprintf(key, "000%i", i); // key size == 8
		SkipDB_at_put_(sdb, Datum_FromCString_(key), Datum_FromCString_(key));
	}
	SkipDBM_commitTransaction(sdbm);
	timerDone(t1, "group transactional inserts");
	printf("\n");
	
	//SkipDB_show(sdb);
	
	t1 = mtime();
	for (i = MAX; i < MAX * 2; i ++)
	{
		sprintf(key, "000%i", i); // key size == 8
		SkipDBM_beginTransaction(sdbm);
		SkipDB_at_put_(sdb, Datum_FromCString_(key), Datum_FromCString_(key));
		SkipDBM_commitTransaction(sdbm);
	}
	timerDone(t1, "individual transactional updates");
	
	    
	t1 = mtime();
	SkipDBM_beginTransaction(sdbm);
	
	for (i = MAX; i < MAX * 2; i ++)
	{
		sprintf(key, "000%i", i); // key size == 8
		SkipDB_at_put_(sdb, Datum_FromCString_(key), Datum_FromCString_(key));
	}
	
	if (SkipDB_headerIsEmpty(sdb))
	{
		printf("1 header is empty!\n");
	}
	
	SkipDBM_commitTransaction(sdbm);
	
	
	if (SkipDB_headerIsEmpty(sdb))
	{
		printf("2 header is empty!\n");
	}
	
	//SkipDB_show(sdb);
	
	timerDone(t1, "group transactional updates");
	printf("\n");
	
	//SkipDB_clearCache(sdb);
	
	t1 = mtime();
	
	//printf("MAX = %i\n", MAX);
	
	for (i = MAX; i < MAX * 2; i ++)
	{
		Datum v;
		
		sprintf(key, "000%i", i); // key size == 8
		
		v = SkipDB_at_(sdb, Datum_FromCString_(key));
		
		if (!v.data)
		{
			printf("data NULL for key %s\n", key);
			v = SkipDB_at_(sdb, Datum_FromCString_(key));
			exit(1);
		}
		
		if (strcmp((char *)key, (char *)v.data) != 0)
		{
			printf("data '%s' doesn't match for key %s\n", v.data, key);
			exit(1);
		}
	}
	
	timerDone(t1, "fresh reads");
	
	t1 = mtime();
	for (i = MAX; i < MAX * 2; i ++)
	{
		sprintf(key, "%i", i);
		SkipDB_at_(sdb, Datum_FromCString_(key));
	}
	timerDone(t1, "possibly cached reads");
	
	//SkipDB_show(sdb);
	
	t1 = mtime();
	SkipDBM_beginTransaction(sdbm);
	
	for (i = MAX; i < MAX * 2; i = i + 2)
	{
		sprintf(key, "000%i", i);
		SkipDB_removeAt_(sdb, Datum_FromCString_(key));
	}
	
	SkipDBM_commitTransaction(sdbm);
	timerDone(t1, "group transactional removes");
	
	t1 = mtime();
	
	{
		double c = SkipDBM_compact(sdbm);
		double dt = timerDone(t1, 0x0);
		//printf("compacted %i records in %.3f seconds\n", (int)c, (float)dt);
		printf("%.1fK transactional compactions per second\n", (c / dt)/1000.0);
	}
	
	//timerDone(t1, "transactional compactions");
	//SkipDB_show(sdb);
	
	SkipDBM_free(sdbm);
	printf("\n");
}


int main(int argc, const char * argv[]) 
{
	//Hash_UnitTest();
	udbTest();
	udbSpeedTest();
	skipTest();
	skipSpeedTest();
	return 0;
}
